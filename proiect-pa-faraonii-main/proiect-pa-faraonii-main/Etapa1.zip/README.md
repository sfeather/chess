# proiect-pa-faraonii
proiect-pa-faraonii created by GitHub Classroom

##
- Nume proiect: Proiect PA
- Nume echipă: Faraonii
- Membri echipă: Bița Răzvan-Nicolae, Iancu George, Pană Ștefan, Prioteasa Cristi-Andrei
- Grupa: 322CC

##
- Makefile:
	- BUILD: 
		 - se compilează sursele java și se generează fișierele .class;
		 - apoi se creează un fișier bot.jar;
		 - pentru fisierul bot.jar folosim și MANIFEST.MF care indică clasa care conține metoda main (ceva similar cu entry-point cred);
	- CLEAN: 
	 	 - ștergerea fișierelor .class și .jar și fișierele de debug;
	- RUN:   
	 	 - rulează programul (apoi pentru a folosi engine-ul în Xboard folosim xboard -fcp "make run" -debug);

##
- Structura proiectului:
	- Clasa MyScanner: Clasa pentru citire (am luat-o din indicațiile pentru testele practice);
	- Clasa Pieces:    Conține codificările pentru fiecare piesă/celulă goală printr-o literă (ex.: WHITE/BLACK_KING = 'k/K'). Am ales să codificăm EMPTY_TITLE 
			   cu '_';
	- Clasa Position:  Reține poziția (linie și coloană) pentru o piesă într-o matrice (codificarea tablei de șah). De asemenea, realizează codificarea poziției
			   din matrice în formatul dorit de XBoard (de ex. (1, 4) -> e2);
	- Clasa Player:    Reține pozițiile pieselor unui jucător, prin câte un ArrayList<Position> pentru fiecare tip de piesă exceptând regele (la regină am
		           considerat cazul în care se ajunge cu un pion la capăt și se pot face mai multe), și mai avem o funcție folosită pentru debug;		
	- Clasa Game:      Reține stare jocului: o variabilă care zice dacă este rândul engine-ului sau al adversarului, o variabilă care zice ce culoare trebuie să
		           mute acum (0 pentru alb și 1 pentru negru), o variabilă de tip boolean care zice dacă engine-ul este pornit sau nu (pentru force și go), 
		           o matrice de caractere (codificarea tablei de șah), un vector Player[] players, cu players[0] -> jucătorul alb, players[1] -> negru. În 
		           această clasă, inițializăm jocul (tabla de joc, fiecare jucător, și toate piesele de pe tablă). De asemenea, avem o metodă prin care schimbăm
		           culoarea și comutăm între engine și oponent dacă nu suntem în force;
	- Clasa Xboard:    Aceasta este clasa în care comunicăm cu xboard (primim și scriem comenzi). La comanda "feature" am pus și opțiunile "usermove = 1" (ca să primim
	                   mutări sub forma "usermove e2e4") și variants=\"3check\" (pentru că asta e versiunea de șah); 

##
- Abordarea algoritmică a etapei:
	- În general, pentru a realiza o mutare, știm poziția inițială și cea finală a piesei pe care o mutăm. Dacă unde mutăm este o piesă
	  a celuilalt jucător, vedem în matrice ce piesă este și o ștergem din ArrayList-ul piesei corespunzătoare a jucătorului (pentru etapa asta punem null,
	  pentru că în cazul pionului să știm că îl mutăm pe același). Apoi schimbăm poziția piesei (mutate) din ArrayList-ul corespunzător al jucătorului care
	  mută și actualizăm în matrice. De asemenea, dacă este vorba de o mutare de pion în urma căreia rezultă transformarea în regină, poziția pionului devine
          null și adăugăm o nouă regină în ArrayList-ul corespunzător;
	- Pentru mutările oponentului (primite de la xboard), decodificăm mutarea (format "e2e4") în coordonate din matricea 8x8. Verificăm dacă este
          o rocadă, iar în cazul în care este o rocadă, mutarea este spartă în 2 mutări (cea a regelui și cea a turei). Astfel, pentru fiecare codificare
	  de rocadă (care reprezintă mutarea regelui), asociem o mutare complementară (cea a turei). În rest, procesul de mutare este explicat mai sus;
	- Pentru mutările engine-ului, folosim o funcție care mută un pion cu index dat. Pentru început, ia din ArrayList-ul de pioni al culorii curente
	  poziția acestui pion. Dacă poziția este null, înseamnă că pionul a fost capturat -> întoarcem "resign". Altfel, pentru această poziție, se
          generează pozițiile în care merge mutat pionul (mai întâi se verifică dacă se poate captura - mers în diagonală, apoi dacă poate înainta cu 2 
	  celule, respectiv cu o celulă). Dacă nu s-a generat nicio astfel de poziție, nu mai putem muta pionul -> întoarcem "resign". Altfel, facem
	  mutarea (în matrice și ArrayList-uri) și construim șirul de forma "move e2e4" care va fi returnat (cu atenție în cazul în care este vorba
	  de o mutare în urma căreia rezultă transformarea pionului în regină, de pus un 'q' la finalul șirului).
	  
##
- Surse de inspirație:
	- YouTube pentru a înțelege mai bine cum funcționează XBoard;
	- am căutat pe net pentru partea de compilare, fiindcă suntem obișnuiți să facă IDE-ul build;
	- clasa MyScanner din indicațiile pentru testele practice (https://pastebin.com/XGUjEyMN);

##
- Responsabilitatea fiecărui membru al echipei:
	- Bița Răzvan-Nicolae: discuția despre cum implementăm, codificarea pieselor (clasa Pieces), deletePiece, moveAsPlayer, movePawn, README
	- Iancu George: discuția despre cum implementăm, Makefile, changePosition, fișier debug, moveAsPlayer, movePawn, comentarii + aranjat cod, README
	- Pană Ștefan: discuția despre cum implementăm, inițializare Game, deletePiece, changePosition, moveAsPlayer, movePawn, README
	- Prioteasa Cristi-Andrei: discuția despre cum implementăm, clasa Position + ideea cu ArrayList din Player, moveAsPlayer, movePawn, comentarii + aranjat cod, README
