import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

enum Turn {
    ENGINE, OPPONENT
}

public class Game {
    // players[0] -> alb, players[1] -> negru
    public Player[] players;
    // tabla
    public char[][] table;
    // folosita pentru modul force (spune daca engine-ul e pornit)
    public boolean isEngineOn;
    // randul engine-ului sau al oponentului
    public Turn currentTurn;
    // 0 -> alb, 1 -> negru
    public int currentColor;

    // initializare joc
    public void initGame() {
        // incepe oponentul, avand culoarea alb
        currentTurn = Turn.OPPONENT;
        currentColor = 0;
        isEngineOn = true;
        players = new Player[2];
        players[0] = new Player();
        players[1] = new Player();
        table = new char[8][8];
        // pune piesele in pozitiile initiale
        for (int i = 2; i < 6; i++) {
            for (int j = 0; j < 8; j++) {
                table[i][j] = Pieces.EMPTY_TILE;
            }
        }

        for (int j = 0; j < 8; j++) {
            table[1][j] = Pieces.WHITE_PAWN;
            players[0].pawns.add(new Position(1, j));
            table[6][j] = Pieces.BLACK_PAWN;
            players[1].pawns.add(new Position(6, j));
        }

        table[0][0] = table[0][7] = Pieces.WHITE_ROOK;
        players[0].rooks.add(new Position(0, 0));
        players[0].rooks.add(new Position(0, 7));

        table[0][1] = table[0][6] = Pieces.WHITE_KNIGHT;
        players[0].knights.add(new Position(0, 1));
        players[0].knights.add(new Position(0, 6));

        table[0][2] = table[0][5] = Pieces.WHITE_BISHOP;
        players[0].bishops.add(new Position(0, 2));
        players[0].bishops.add(new Position(0, 5));

        table[0][3] = Pieces.WHITE_QUEEN;
        players[0].queens.add(new Position(0, 3));

        table[0][4] = Pieces.WHITE_KING;
        players[0].king = new Position(0, 4);

        table[7][0] = table[7][7] = Pieces.BLACK_ROOK;
        players[1].rooks.add(new Position(7, 0));
        players[1].rooks.add(new Position(7, 7));

        table[7][1] = table[7][6] = Pieces.BLACK_KNIGHT;
        players[1].knights.add(new Position(7, 1));
        players[1].knights.add(new Position(7, 6));

        table[7][2] = table[7][5] = Pieces.BLACK_BISHOP;
        players[1].bishops.add(new Position(7, 2));
        players[1].bishops.add(new Position(7, 5));

        table[7][3] = Pieces.BLACK_QUEEN;
        players[1].queens.add(new Position(7, 3));

        table[7][4] = Pieces.BLACK_KING;
        players[1].king = new Position(7, 4);
    }
    // afisare pentru debug (tabla)
    public void printTable(FileWriter debugFile) {
        try {
            debugFile.write("  a b c d e f g h\n");
            for (int i = 8; i > 0; i--) {
                String line = "" + i;
                for (int j = 0; j < 8; j++) {
                    line = line + " " + table[i - 1][j];
                }
                line = line + " " + i + "\n";
                debugFile.write(line);
            }
            debugFile.write("  a b c d e f g h\n");
            debugFile.write("\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    // schimba culoarea si comuta intre engine si oponent
    // daca nu suntem in force
    public void changeTurn() {
        currentColor = 1 - currentColor;
        if (isEngineOn) {
            if (currentTurn == Turn.ENGINE)
                currentTurn = Turn.OPPONENT;
            else
                currentTurn = Turn.ENGINE;
        }
    }
    // sterge piesa de la pozitia pos din piesele jucatorului care nu muta acum
    public void deletePiece(Position pos) {
        // iau piesa din matrice
        char pieceToDelete = table[pos.getLine()][pos.getColumn()];
        // la indexul asta probabil renuntam la etapele urmatoare
        // e folosit pentru a reusi sa utilizam acelasi pion
        int index;

        // daca piesa reprezinta o celula libera, nu facem nimic
        if (pieceToDelete == Pieces.EMPTY_TILE)
            return;
        // daca piesa este pion
        // liniile comentate din if-urile astea o sa le folosim la etapele
        // urmatoare
        if (pieceToDelete == Pieces.BLACK_PAWN + 32 * currentColor) {
            // luam indexul pionului
            index = players[1 - currentColor].pawns.indexOf(pos);
            // "stergem" pionul din ArrayList (la etapele urmatoare probabil o
            // sa folosim remove si add pentru chestii din astea)
            players[1 - currentColor].pawns.set(index, null);
            //players[1 - currentColor].pawns.remove(pos);
        } else if (pieceToDelete == Pieces.BLACK_BISHOP + 32 * currentColor) {
            // de aici e similar pentru celelalte tipuri de piese
            index = players[1 - currentColor].bishops.indexOf(pos);
            players[1 - currentColor].bishops.set(index, null);
            //players[1 - currentColor].bishops.remove(pos);
        } else if (pieceToDelete == Pieces.BLACK_KNIGHT + 32 * currentColor) {
            index = players[1 - currentColor].knights.indexOf(pos);
            players[1 - currentColor].knights.set(index, null);
            //players[1 - currentColor].knights.remove(pos);
        } else if (pieceToDelete == Pieces.BLACK_ROOK + 32 * currentColor) {
            index = players[1 - currentColor].rooks.indexOf(pos);
            players[1 - currentColor].rooks.set(index, null);
            //players[1 - currentColor].rooks.remove(pos);
        } else if (pieceToDelete == Pieces.BLACK_QUEEN + 32 * currentColor) {
            index = players[1 - currentColor].queens.indexOf(pos);
            players[1 - currentColor].queens.set(index, null);
            //players[1 - currentColor].queens.remove(pos);
        }
    }
    // functie care realizeaza mutarea in ArrayListii jucatorilor, intre 2 pozitii
    public void changePosition(Position before, Position after) {
        // ia piesa din matrice
        char pieceToChange = table[before.getLine()][before.getColumn()];
        // iar indexul asta
        int index;
        // liniile comentate vor fi folosite in etapele urmatoare
        // daca piesa pe care o mutam este pion, editam pozitia sa din
        // ArrayListul de pozitii ale pionilor
        if (pieceToChange == Pieces.WHITE_PAWN - 32 * currentColor) {
            // cauta pionul in ArrayList
            index = players[currentColor].pawns.indexOf(before);
            //players[currentColor].pawns.remove(before);
            // cazul de transformare in regina
            if (after.getLine() == 7 - 7 * currentColor) {
                // stergem pionul din ArrayListul de pioni
                players[currentColor].pawns.set(index, null);
                // adaugam o noua regina
                players[currentColor].queens.add(after);
                // if-ul asta merge inlocuit cu o expresie
                if (currentColor == 0) {
                    table[before.getLine()][before.getColumn()] = Pieces.WHITE_QUEEN;
                } else {
                    table[before.getLine()][before.getColumn()] = Pieces.BLACK_QUEEN;
                }
            } else {
                // daca e o mutare normala
                // editam pozitia
                players[currentColor].pawns.set(index, after);
                //players[currentColor].pawns.add(after);
            }
        } else if (pieceToChange == Pieces.WHITE_BISHOP - 32 * currentColor) {
            // similar pentru celelalte piese
            index = players[currentColor].bishops.indexOf(before);
            players[currentColor].bishops.set(index, after);
            //players[currentColor].bishops.remove(before);
            //players[currentColor].bishops.add(after);
        } else if (pieceToChange == Pieces.WHITE_KNIGHT - 32 * currentColor) {
            index = players[currentColor].knights.indexOf(before);
            players[currentColor].knights.set(index, after);
            //players[currentColor].knights.remove(before);
            //players[currentColor].knights.add(after);
        } else if (pieceToChange == Pieces.WHITE_ROOK - 32 * currentColor) {
            index = players[currentColor].rooks.indexOf(before);
            players[currentColor].rooks.set(index, after);
            //players[currentColor].rooks.remove(before);
            //players[currentColor].rooks.add(after);
        } else if (pieceToChange == Pieces.WHITE_QUEEN - 32 * currentColor) {
            index = players[currentColor].queens.indexOf(before);
            players[currentColor].queens.set(index, after);
            //players[currentColor].queens.remove(before);
            //players[currentColor].queens.add(after);
        } else {
            players[currentColor].king = after;
        }
    }
    // realizeaza o mutare primita de la xboard
    public void moveAsPlayer(String move) {
        // rocadele
        ArrayList<String> castlings = new ArrayList<>();
        castlings.add("e1g1");
        castlings.add("e1c1");
        castlings.add("e8g8");
        castlings.add("e8c8");
        ArrayList<String> complementary = new ArrayList<>();
        complementary.add("h1f1");
        complementary.add("a1d1");
        complementary.add("h8f8");
        complementary.add("a8d8");
        // determina coordonatele
        int line1 = move.charAt(1) - '1';
        int col1 = move.charAt(0) - 'a';
        int line2 = move.charAt(3) - '1';
        int col2 = move.charAt(2) - 'a';
        Position before = new Position(line1, col1);
        Position after = new Position(line2, col2);
        // caz rocada
        if (table[line1][col1] == Pieces.WHITE_KING - 32 * currentColor) {
            for (int i = 0; i < 4; i++) {
                if (castlings.get(i).equals(move)) {
                    changePosition(before, after);
                    table[line2][col2] = table[line1][col1];
                    table[line1][col1] = Pieces.EMPTY_TILE;
                    String compl = complementary.get(i);
                    line1 = compl.charAt(1) - '1';
                    col1 = compl.charAt(0) - 'a';
                    line2 = compl.charAt(3) - '1';
                    col2 = compl.charAt(2) - 'a';
                    before = new Position(line1, col1);
                    after = new Position(line2, col2);
                    changePosition(before, after);
                    table[line2][col2] = table[line1][col1];
                    table[line1][col1] = Pieces.EMPTY_TILE;
                    return;
                }
            }
        }
        // muta piesa
        changePosition(before, after);
        // sterge piesa care se afla dinainte pe pozitia de final
        deletePiece(after);
        // editam si in matrice
        char pieceToMove = table[line1][col1];
        table[line2][col2] = pieceToMove;
        table[line1][col1] = Pieces.EMPTY_TILE;
    }
    // functia de mutat pionul de catre engine
    // parametru: indexul pionului
    // iesire: sir de forma "move e2e4"
    public String movePawn(int index) {
        // ia pozitia pionului
        Position pawn = players[currentColor].pawns.get(index);
        // daca pionul nu mai exista, cedam partida
        if (pawn == null)
            return "resign";
        // codificarea pentru pozitia initiala
        String before = pawn.encode();
        int line = pawn.getLine();
        int column = pawn.getColumn();
        // ArrayListul de mutari posibile (pozitii finale)
        ArrayList<Position> possibleMoves = new ArrayList<>();
        // determina mutarile posibile
        if (currentColor == 0) {
            // primele 2 if-uri sunt pentru capturat piese
            if (column > 0 && table[line + 1][column - 1] <= 'Z')
                possibleMoves.add(new Position(line + 1, column - 1));
            if (column < 7 && table[line + 1][column + 1] <= 'Z')
                possibleMoves.add(new Position(line + 1, column + 1));
            // if-ul asta e pentru mutarea "in fata" cu 1 sau 2 patratele
            if (table[line + 1][column] == Pieces.EMPTY_TILE) {
                if (line == 1 && table[line + 2][column] == Pieces.EMPTY_TILE)
                    possibleMoves.add(new Position(line + 2, column));
                possibleMoves.add(new Position(line + 1, column));
            }
        } else {
            // la fel pentru negru
            if (column > 0 && table[line - 1][column - 1] >= 'a')
                possibleMoves.add(new Position(line - 1, column - 1));
            if (column < 7 && table[line - 1][column + 1] >= 'a')
                possibleMoves.add(new Position(line - 1, column + 1));
            if (table[line - 1][column] == Pieces.EMPTY_TILE) {
                if (line == 6 && table[line - 2][column] == Pieces.EMPTY_TILE)
                    possibleMoves.add(new Position(line - 2, column));
                possibleMoves.add(new Position(line - 1, column));
            }
        }
        // daca nu putem muta pionul, cedam partida
        if (possibleMoves.size() == 0)
            return "resign";
        // luam prima mutare disponibila (le-am generat pe toate pentru a
        // utiliza codul in alte etape
        Position movedPawn = possibleMoves.get(0);
        // codificarea pentru pozitia finala
        String after = movedPawn.encode();
        // construirea sirului de forma "move e2e4" sau move "e7e8q"
        String result;
        if (movedPawn.getLine() == 0 || movedPawn.getLine() == 7) {
            result = "move " + before.concat(after) + "q";
        } else {
            result = "move " + before.concat(after);
        }
        // realizarea mutarii (similar ca la player)
        changePosition(pawn, movedPawn);
        deletePiece(movedPawn);
        char pieceToMove = table[pawn.getLine()][pawn.getColumn()];
        table[movedPawn.getLine()][movedPawn.getColumn()] = pieceToMove;
        table[pawn.getLine()][pawn.getColumn()] = Pieces.EMPTY_TILE;
        // returneaza comanda care va fi trimisa la xboard
        return result;
    }
}
