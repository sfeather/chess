import java.io.FileWriter;
import java.io.IOException;

public class XBoard {
    public static void main(String[] args) {
        MyScanner sc = new MyScanner();
        String currentCommand;
        Game currentGame = new Game();
        try {
            // fisier pentru debug
            FileWriter debugFile = new FileWriter("debug.txt");
            while (true) {
                // daca este randul engine-ului, muta pionul
                if (currentGame.currentTurn == Turn.ENGINE) {
                    // am pus sa mute pioni "simetrici" in functie de culoare
                    System.out.println(currentGame.movePawn(1 +
                            5 * currentGame.currentColor));
                    System.out.flush();
                    currentGame.changeTurn();
                    // debug: afiseaza tabla si pozitiile pionilor
                    currentGame.printTable(debugFile);
                    currentGame.players[0].printPositions(debugFile);
                    currentGame.players[1].printPositions(debugFile);
                    continue;
                }
                // primeste comanda de la xboard
                currentCommand = sc.nextLine();
                if (currentCommand.compareTo("xboard") == 0) {
                    currentGame.initGame();
                    currentGame.printTable(debugFile);
                    continue;
                }

                if (currentCommand.startsWith("protover")) {
                    System.out.println("feature sigint=0 san=0 myname=\"Faraonii\" usermove=1 variants=\"3check\"");
                    System.out.flush();
                    continue;
                }

                if (currentCommand.compareTo("new") == 0) {
                    currentGame.initGame();
                    continue;
                }
                // in modul force, engine-ul este dezactivat
                if (currentCommand.compareTo("force") == 0) {
                    currentGame.isEngineOn = false;
                    currentGame.currentTurn = Turn.OPPONENT;
                    continue;
                }
                // in modul go, reintra engine-ul in joc
                // muta pentru culoarea curenta
                if (currentCommand.compareTo("go") == 0) {
                    currentGame.isEngineOn = true;
                    currentGame.currentTurn = Turn.ENGINE;
                    continue;
                }
                // inchiderea jocului
                if (currentCommand.compareTo("quit") == 0) {
                    debugFile.close();
                    return;
                }
                // mutarile jucatorului (primite de la xboard)
                // de forma "usermove e2e4"
                if (currentCommand.startsWith("usermove")) {
                    String move = currentCommand.split(" ")[1];
                    currentGame.moveAsPlayer(move);
                    currentGame.changeTurn();
                    // linii debug: afiseaza tabla si pozitiile pionilor
                    currentGame.printTable(debugFile);
                    currentGame.players[0].printPositions(debugFile);
                    currentGame.players[1].printPositions(debugFile);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
