public class KingSideCastleMove extends Move {
}
