public class QueenSideCastleMove extends Move {

}
